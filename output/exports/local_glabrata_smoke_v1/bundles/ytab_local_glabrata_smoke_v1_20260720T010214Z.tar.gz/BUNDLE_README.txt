YTAB compact reproducibility bundle

Includes configuration, manifests, stable summaries, plots, results, and report.
FASTQ, BAM, SAM, hit files, and normalized hit files are excluded unless explicitly requested.
